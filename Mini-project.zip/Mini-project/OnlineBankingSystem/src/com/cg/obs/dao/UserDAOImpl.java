package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.util.DBUtil;

public class UserDAOImpl implements IUserDAO {

	PreparedStatement pst;
	Connection con;
	Statement st;
	@Override
	public Users getUser(String id) throws UserException {
		
		Users user=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM USER_TABLE WHERE USER_ID=?";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			user=new Users();
		
			user.setUserId(rs.getString(1));
			user.setAccountId(rs.getInt(2));
			user.setLoginPassword(rs.getString(3));
			user.setSecretQuestion(rs.getString(4));
			user.setLockStatus(rs.getString(5));
			user.setTransPassword(rs.getString(6));
			
			
			System.out.println(user);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return user;
	}


}
