package com.cg.obs.service;


import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;
import com.cg.obs.dao.AdminDaoImpl;
import com.cg.obs.dao.IAdminDao;
import com.cg.obs.dao.IUserDAO;
import com.cg.obs.dao.UserDAOImpl;
import com.cg.obs.exception.UserException;

public class UserServiceImpl implements IUserService {

	IUserDAO userDao;
	IAdminDao adminDao;
	public UserServiceImpl() {
		userDao=new UserDAOImpl();
		adminDao=new AdminDaoImpl();
	}
	
	
	
	@Override
	public Users getUser(String id) throws UserException {
		
		return userDao.getUser(id);
	}

	@Override
	public Admin getAdmin(String id) throws UserException {
		
		return adminDao.getAdmin(id);
	}

}
