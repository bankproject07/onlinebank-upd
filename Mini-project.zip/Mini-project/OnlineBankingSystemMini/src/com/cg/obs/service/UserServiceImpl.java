package com.cg.obs.service;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;
import com.cg.obs.dao.IUserDAO;
import com.cg.obs.dao.UserDAOImpl;
import com.cg.obs.exception.UserException;

public class UserServiceImpl implements IUserService {

	IUserDAO userDao;
	public UserServiceImpl() {
		userDao=new UserDAOImpl();
	}
	@Override
	public Users getUser(String id) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getUser(id);
	}

	@Override
	public Admin getAdmin(String id) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getAdmin(id);
	}

}
